
public class JumpException extends Exception{
	String e;
	public JumpException(String e){
		this.e=e;
	}
}
