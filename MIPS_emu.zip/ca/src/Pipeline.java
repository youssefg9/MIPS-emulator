import java.util.LinkedList;
import java.util.Queue;

public class Pipeline {
	int counter;
	CPU CPU;
	 int numberOfClockCycles ;
	 int numberOfClockCyclesTemp ;
	 Instruction currCycleInst;
	 Queue<Instruction> fetchQueue = new LinkedList<Instruction>();
	 Queue<Instruction> decodeQueue = new LinkedList<Instruction>();
	 Queue<Instruction> executeQueue = new LinkedList<Instruction>();
	 Queue<Instruction> MemQueue = new LinkedList<Instruction>();
	 Queue<Instruction> WriteBackQueue = new LinkedList<Instruction>();
public Pipeline (CPU CPU){
	this.CPU=CPU;
	numberOfClockCycles = (7 + (CPU.intsructionCount - 1) * 2);
	//System.out.println("Calculations of Cycles : "+numberOfClockCycles);
	numberOfClockCyclesTemp=numberOfClockCycles;
}
	public  void dataPathQueues() {
int i =CPU.pc;
		for (; i < CPU.intsructionCount; i++) {
			//System.out.println("Fetched the one with pc : "+i);
			Instruction temp=new Instruction( CPU.Memory[i],i);
			//System.out.println(temp.rs);
			
			fetchQueue.add(temp);
			fetchQueue.add(null);
			
		}
		i =CPU.pc;
		decodeQueue.add(null);
		for ( ; i < CPU.intsructionCount; i++) {
			Instruction temp=new Instruction( CPU.Memory[i],i);
			decodeQueue.add(temp);
			decodeQueue.add(temp);

		}
		i =CPU.pc;
		executeQueue.add(null);
		executeQueue.add(null);
		executeQueue.add(null);
		for (; i < CPU.intsructionCount; i++) {
			Instruction temp=new Instruction( CPU.Memory[i],i);
			executeQueue.add(temp);
			executeQueue.add(temp);

		}
		i =CPU.pc;
		MemQueue.add(null);
		MemQueue.add(null);
		MemQueue.add(null);
		MemQueue.add(null);
		MemQueue.add(null);
		//MemQueue.add(null);
		for (; i < CPU.intsructionCount; i++) {
			MemQueue.add(new Instruction( CPU.Memory[i],i));
			MemQueue.add(null);

		}
		i =CPU.pc;
		WriteBackQueue.add(null);
		WriteBackQueue.add(null);
		WriteBackQueue.add(null);
		WriteBackQueue.add(null);
		WriteBackQueue.add(null);
		WriteBackQueue.add(null);
		for (; i < CPU.intsructionCount; i++) {
			WriteBackQueue.add(new Instruction( CPU.Memory[i],i));
			WriteBackQueue.add(null);

		}

		

	}
	//public void jumped(){
		
	//}
	public  void popFromQueues() throws Exception {
		try {
			
		
		// handles the events of each cycle
		System.out.println("OutOfEx : in this cycle :"+CPU.outOfExecute);
			currCycleInst = fetchQueue.poll();
			if (currCycleInst != null) {
				CPU.fetch();
				System.out.println("Fetched is : "+currCycleInst.toString());
			}
			currCycleInst = decodeQueue.poll();
			if (currCycleInst != null) {
				if(decodeQueue.peek()!=currCycleInst){
					System.out.println("Finish Decoding  : "+currCycleInst.toString());
					CPU.decode();
					//finish decoding at end of the stage
				}else
					System.out.println("Starts Decoding  : "+currCycleInst.toString());

				
			}
			//TODO rag3o 3leha tany
			currCycleInst = WriteBackQueue.poll();
			if (currCycleInst != null) {
				System.out.println("Write back is : "+currCycleInst.toString());
				CPU.writeBack(currCycleInst.getValues());
				
			}
			currCycleInst = executeQueue.poll();
			if (currCycleInst != null) {
				
				//CPU.execute(currCycleInst.getValues());
				if(executeQueue.peek()!=currCycleInst){
					System.out.println("Executed is : "+currCycleInst.toString());
					CPU.execute(currCycleInst.getValues());
					//finish decoding at end of the stage
				}
			}
			currCycleInst = MemQueue.poll();
			if (currCycleInst != null) {
				System.out.println("Memory Access is : "+currCycleInst.toString());
				CPU.MemoryAccess(currCycleInst.getValues());
			}
		} catch (JumpException e) {
			 fetchQueue = new LinkedList<Instruction>();
			 fetchQueue.add(null);
			 decodeQueue = new LinkedList<Instruction>();
			 decodeQueue.add(null);
			 executeQueue = new LinkedList<Instruction>();
			 executeQueue.add(null);
			 //these nulls are for the jump memory access for jump instructions
			 MemQueue = new LinkedList<Instruction>();
			 WriteBackQueue = new LinkedList<Instruction>();
			 dataPathQueues();
			 
			// TODO: handle exception
		}

		}
	

}
