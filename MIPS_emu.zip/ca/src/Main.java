import java.io.File; // Import the File class
import java.io.FileNotFoundException; // Import this class to handle errors
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
//TODO Jumps , exception 

public class Main {

	public static void main(String[] args) throws Exception {
		ArrayList<String[]> code = new ArrayList<String[]>();
		try {
			PrintStream fileOut = new PrintStream(System.getProperty("user.dir")
					+ "\\src\\out.txt");
			System.setOut(fileOut);
			// creating the asm file
			File myObj = new File(System.getProperty("user.dir")
					+ "\\src\\asm.txt");
			Scanner myReader = new Scanner(myObj);
			int i = 0;
			while (myReader.hasNextLine()) {

				String data = myReader.nextLine();
				
				String[] Values = data.split(" ");
				if(Values.length<2) {
					continue;
				}
				code.add(Values);

			}
			// creating the cpu object
			CPU Fillet_O_Neumann = new CPU(code);
			Fillet_O_Neumann.pipe.dataPathQueues();
			
			System.out.println("numberOfClockCyclesTemp:  "
					+ Fillet_O_Neumann.pipe.numberOfClockCyclesTemp);
			for (int c = 0; !Fillet_O_Neumann.pipe.WriteBackQueue.isEmpty(); c++) {
			//	System.out.println(Fillet_O_Neumann.pipe.WriteBackQueue.size());
				System.out.println("--------------------------------"); 
				System.out.println("cycle : "+(c+1));
				Fillet_O_Neumann.pipe.popFromQueues();
//				for(int cc=1;cc<10;cc++){
//					System.out.println("Register : " + Fillet_O_Neumann.Regs[cc].getIndex()
//							+ " has value : " + Fillet_O_Neumann.Regs[cc].getValue());
//				}
			}
			for(int c=0;c<2048;c++){
				{
					System.out.println("Memory Loc : "+c+" has Value : "+Fillet_O_Neumann.Memory[c]);
				}
			}

			for (Register reg : Fillet_O_Neumann.Regs) {
				System.out.println("Register : " + reg.getIndex()
						+ " has value : " + reg.getValue());
			}

			myReader.close();

		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

	}

}
