
public class MemoryData implements MemoryObject {
	int value;
	public MemoryData(int value) {
		this.value=value;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int getValue() {
		// TODO Auto-generated method stub
		return value;
	}
	public void setValue(int value) {
		// TODO Auto-generated method stub
		this.value = value ;
	}
}
