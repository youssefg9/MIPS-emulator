
public class Register {
	int value;
	int index;
	public Register(int value,int index) {
		this.index=index;
		// TODO Auto-generated constructor stub
		this.value=value;
	}
	public int getValue() {
		return value;
	}
	public int setValue(int value) {
		this.value=value;
		return value;
		// TODO Auto-generated method stub
		
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
}