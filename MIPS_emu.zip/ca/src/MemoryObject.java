
public interface MemoryObject {
public int getValue();

public void setValue(int value);
}
