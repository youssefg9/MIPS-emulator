import java.lang.Math;
import java.util.ArrayList;

public class Instruction implements MemoryObject {
	String stringValues=" ";
	String[] Values;
	int opcode;
	int value;
	int type;
	int rd;
	int rs;
	int rt;
	int imm;
	int address;
	int shamt;
	int pc;
	// R is 0 , I is 1 , J is 2
	public Instruction(int value,int pc) {
		this.pc=pc;
		opcode=(value & 0b11110000000000000000000000000000);
		opcode =(opcode >> 28)&0b01111;
		getType(opcode);
		getOperands(value);
		
		
	}
	public Instruction(String[] Values) throws Exception {
		for (String string : Values) {
			stringValues+=string+" ";
		}
	
		shamt = 0;
		this.opcode = getOpcode(Values[0]);
		
		type=this.getType(opcode);
		getOperands(Values,type);
		

		// TODO Handle Exception
	}

	static int getOpcode(String inst) throws Exception {
		switch (inst) {
		case "ADD":
			return 0;
		case "SUB":
			return 1;
		case "MULI":
			return 2;
		case "ADDI":
			return 3;
		case "BNE":
			return 4;
		case "ANDI":
			return 5;
		case "ORI":
			return 6;
		case "J":
			return 7;
		case "SLL":
			return 8;
		case "SRL":
			return 9;
		case "LW":
			return 10;
		case "SW":
			return 11;
		default:
			throw new Exception("Invalid Instruction :" + inst);
		}

	}
	public void getOperands(int value){
		switch ( type) {
		case 0: {
			if(opcode==8||opcode==9) {
				shamt=value&0b1111111111111;
			//	System.out.println("shamt : "+shamt);
			}else
				{
				rt =  ((value&0b111110000000000000)>>13)&0b11111 ;
				}
			rd =  ((value&0b1111100000000000000000000000)>>23)&0b11111;
			rs =  ((value&0b11111000000000000000000)>>18)&0b11111;
			
			
			break;
		}
		case 1: {
			rd =  ((value&0b1111100000000000000000000000)>>23)&0b11111;
			rs =  ((value&0b11111000000000000000000)>>18)&0b11111;
			imm  = value&0b111111111111111111;
			if((imm&0b100000000000000000)!=0) {
				imm=imm|0b11111111111111000000000000000000;
			}
			// 
			//imm=imm&262143;
			
			
			
			break;
		}
		case 2: {
			address = (value&0b1111111111111111111111111111);
			
			break;
		}
		}
	}
public void getOperands(String[] Values ,int type){
	switch ( type) {
	case 0: {
		if(opcode==8||opcode==9) {
			shamt=Integer.parseInt(Values[3]);
			rt=0;
		//	System.out.println("shamt : "+shamt);
		}else
			{
			rt =  getReg(Values[3]);
			shamt=0;
			}
		rd = getReg(Values[1]);
		rs =  getReg(Values[2]);
		value=(opcode<<28)+(rd<<23)+(rs<<18)+(rt<<13)+shamt;
		
		//value = opcode * ((int) Math.pow(2, 28)) + rd * ((int) Math.pow(2, 23)) + rs * ((int) Math.pow(2, 18))
		//		+ rt * ((int) Math.pow(2, 13)) + shamt;
		break;
	}
	case 1: {
		rd =getReg(Values[1]);
		rs  = getReg(Values[2]);
		imm  = Integer.parseInt(Values[3]);
		
		//imm=imm&262143;
		value=(opcode<<28)+(rd<<23)+(rs<<18)+(imm&0b0111111111111111111);
		
	//	value = opcode * ((int) Math.pow(2, 28)) + rd * ((int) Math.pow(2, 23)) + rs * ((int) Math.pow(2, 18))
	//			+ imm&262143;
		break;
	}
	case 2: {
		address = Integer.parseInt(Values[1]);
		//value = opcode * ((int) Math.pow(2, 28)) + address;
		value=(opcode<<28)+address;
		break;
	}
	}
}
	static int getReg(String reg) {
		return Integer.parseInt(reg.substring(1, reg.length()));
	}

	public int getValue() {
		// TODO Auto-generated method stub
		return value;
	}
	public String toString() {
		String out="";
		for (String string : CPU.code.get(pc)) {
		out+=string+" ";	
		}
		return out;
//		// TODO Auto-generated method stub
//		ArrayList<Integer>tmp= getValues();
//		String x="";
//		x+="Type IS: "+tmp.get(0)+"\n";
//		x+="Opcode IS: "+tmp.get(1)+"\n";
//		switch (tmp.get(0)) {
//		case 0: {
//			//TODO shifting not implementing
//			x+="rd IS: "+tmp.get(2)+"\n";
//			x+="rs IS: "+tmp.get(3)+"\n";
//			x+="rt IS: "+tmp.get(4)+"\n";
//			x+="shamt IS: "+tmp.get(5)+"\n";
//			
//			break;
//		}
//		case 1: {
//			x+="rd IS: "+tmp.get(2)+"\n";
//			x+="rs IS: "+tmp.get(3)+"\n";
//			x+="imm IS: "+tmp.get(4)+"\n";
//			
//			break;
//		}
//		case 2: {
//			x+="address IS: "+tmp.get(2)+"\n";
//			
//		
//			break;
//		}
//
//		}
//		return x;
		
	}
public int getType(int opcode) {
	switch (opcode) {
	case 0:
	case 1:
	case 8:
	case 9:
		type = 0;
		break;
	case 7:
		type = 2;
		break;
	default:
		type = 1;
	}
	return type;
}
	public ArrayList<Integer> getValues() {
		ArrayList<Integer> outValues = new ArrayList<Integer>();
		outValues.add(type);
		outValues.add(opcode);
		switch (type) {
		case 0: {
			
			outValues.add(rd);
			outValues.add(rs);//TODO check this if not correct
			outValues.add(rt);
			outValues.add(shamt);
			break;
		}
		case 1: {
			outValues.add(rd);
			outValues.add(rs);//TODO check this if not correct
			outValues.add(imm);
			
			break;
		}
		case 2: {
			outValues.add(address);
		
			break;
		}

		}

		return outValues;
	}

	@Override
	public void setValue(int value) {
		// TODO Auto-generated method stub
		
	}
}
