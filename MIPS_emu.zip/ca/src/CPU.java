import java.util.ArrayList;
import java.util.Queue;

public class CPU {
	public int intsructionCount;
	Instruction fetchedInst;
	int fetchedInstValue;
	ArrayList<Integer> DecodedInst;

	ArrayList<Integer> decodedInst = new ArrayList<Integer>();
	int cycle = 1;
	int pc;
	int outOfExecute = 0;
	int outOfMem = 0;
	public int[] Memory = new int[2048];
	Register[] Regs = new Register[33];
	public Pipeline pipe;;
	static ArrayList<String[]> code;

	CPU(ArrayList<String[]> code) throws Exception {
		this.code = code;
		// setting all regs to zero
		for (int i = 0; i < 33; i++) {
			Regs[i] = new Register(0, i);
		}
		// loading the instructions to the memory
		for (int i = 0; i < code.size(); i++) {
			String[] values = code.get(i);
			Instruction inst = new Instruction(values);
			// System.out.println(inst);
			if (i < 1024) {
				Memory[i] = inst.getValue();
			} else
				throw new Exception("Out of Instruction mem boundary");

			intsructionCount++;
			// System.out.println("Inst count : " + intsructionCount);
		}
		pc = Regs[32].value;// pc=0
		pipe = new Pipeline(this);
	}

	public void fetch() throws Exception {
		// TODO el 7ta de mohma >>> when does the pc change ?
		int pc = Regs[32].getValue();
		int inst = (Memory[pc++]);
		Regs[32].setValue(pc);
		fetchedInstValue = inst;
		if (pc > 1024) {
			throw new Exception("Out of Instruction Boundary");
		}

	}

	public void decode() {

		// note that the parameters' order is specified in Instruction class
		fetchedInst = new Instruction(fetchedInstValue, Regs[32].getValue());
		// System.out.println(fetchedInst);
		ArrayList<Integer> pars = fetchedInst.getValues();
		DecodedInst = pars;
		// parameters (operands ) depend on type of instruction
		// first parameter is the type
		// 0 ---> R
		// 1 ---> I
		// 2 ---> J

	}

	public void execute(ArrayList<Integer> temp) throws Exception {
		int R1 = 0, R2 = 0, R3 = 0, IMM = 0, SAM = 0, ADD = 0;
		int opCode = temp.get(1);
		if (temp.size() == 6) {
			R1 = temp.get(2);
			R2 = temp.get(3);
			R3 = temp.get(4);
			SAM = temp.get(5);

		}
		if (temp.size() == 5) {

			R1 = temp.get(2);
			R2 = temp.get(3);
			IMM = temp.get(4);

		} else {
			ADD = temp.get(2);

		}

		switch (opCode) {
		case 0:
			outOfExecute = (Regs[R2].getValue() + Regs[R3].getValue());
			break;
		case 1:
			outOfExecute = (Regs[R2].getValue() - Regs[R3].getValue());
			break;
		case 2:
			outOfExecute = Regs[R2].getValue() * IMM;
			break;
		case 3:
			outOfExecute = Regs[R2].getValue() + IMM;
		//	System.out.println("Added Immediate : " + R2 + "  " + outOfExecute + "  :" + IMM);
			break;
		case 4:
			// check again
			
			if (Regs[R1].getValue() != Regs[R2].getValue()) {

				// branch
				if (Regs[32].getValue() == intsructionCount ) {
					pc=Regs[32].setValue(Regs[32].getValue() + IMM - 1);
				} else if (Regs[32].getValue() == intsructionCount - 1)
					pc=Regs[32].setValue(Regs[32].getValue() + IMM - 2);
				else
					pc =Regs[32].setValue(Regs[32].getValue() + IMM - 3);// case lma b execute jump and fetching another
																		// instruction (2 inst ahead)
				pc = Regs[32].getValue();
				if (Regs[32].getValue()>1024)
					throw new Exception("Out of Instruction mem boundary"); 
				// System.out.println("Jumping");
				throw new JumpException("I branched");
			} else {
				System.out.println("Didn't Jump");
			}
			;
			break;
		case 5:
			outOfExecute = Regs[R2].getValue() & IMM;
			break;
		case 6:
			outOfExecute = Regs[R2].getValue() | IMM;
			break;
		case 7: {
			Regs[32].setValue(ADD);
			pc = Regs[32].getValue();
			throw new JumpException("I Jumped");
		}
		case 8:
			outOfExecute = Regs[R2].getValue() << SAM;

			break;
		case 9:
			outOfExecute = Regs[R2].getValue() >>> SAM;

			break;
		default:
			break;

		}

	}

	public void MemoryAccess(ArrayList<Integer> temp) throws Exception {
		int R1 = 0, R2 = 0, R3 = 0, IMM = 0, SAM = 0, ADD = 0;
		int opCode = temp.get(1);
		if (temp.size() == 6) {
			R1 = temp.get(2);
			R2 = temp.get(3);
			R3 = temp.get(4);
			SAM = temp.get(5);

		}
		if (temp.size() == 5) {

			R1 = temp.get(2);
			R2 = temp.get(3);
			IMM = temp.get(4);

		}

		else {
			ADD = temp.get(2);

		}

		switch (opCode) {
		case 10:
			if (Regs[R2].getValue() + IMM >= 1024 && Regs[R2].getValue() + IMM <= 2047) {
				outOfMem = (Memory[Regs[R2].getValue() + IMM]);
			} else {
				throw new Exception("accessing value outOfBounds");
			}
			break;
		case 11:
			if (Regs[R2].getValue() + IMM >= 1024 & Regs[R2].getValue() + IMM <= 2047) {
				(Memory[Regs[R2].getValue() + IMM]) = Regs[R1].getValue();
				System.out.println("Memoty at : "+(Regs[R2].getValue() + IMM )+" has value of : "+(Memory[Regs[R2].getValue() + IMM]));
			} else {
				throw new Exception("accessing value outOfBounds");
			}
			break;
		default:
			break;
		}

	}

	public void writeBack(ArrayList<Integer> temp) {
		int R1 = 0, R2 = 0, R3 = 0, IMM = 0, SAM = 0, ADD = 0;
		int opCode = temp.get(1);
		if (temp.size() == 6) {
			R1 = temp.get(2);
			R2 = temp.get(3);
			R3 = temp.get(4);
			SAM = temp.get(5);
		}
		if (temp.size() == 5) {
			R1 = temp.get(2);
			R2 = temp.get(3);
			IMM = temp.get(4);

		} else {
			ADD = temp.get(2);
		}

		switch (opCode) {
		case 0:
			Regs[R1].setValue(outOfExecute);
			break;
		case 1:
			Regs[R1].setValue(outOfExecute);
			break;
		case 2:
			Regs[R1].setValue(outOfExecute);
			break;
		case 3:
	//		System.out.println("write : " + outOfExecute);
			Regs[R1].setValue(outOfExecute);
			break;
		case 5:
			Regs[R1].setValue(outOfExecute);
			break;
		case 6:
			Regs[R1].setValue(outOfExecute);
			break;
		case 8:
			Regs[R1].setValue(outOfExecute);
			break;
		case 9:
			Regs[R1].setValue(outOfExecute);
			break;
		case 10:
			Regs[R1].setValue(outOfMem);
			System.out.println("now This Register : "+R1+" has Value of : "+Regs[R1].getValue());
			break;// lw
		default:
			break;

		}
		
		Regs[0].setValue(0);
		System.out.println("now This Register : "+R1+" has Value of : "+Regs[R1].getValue());
		

	}

}
