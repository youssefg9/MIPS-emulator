-the main method takes input from (asm.txt) and outputs in the (out.txt) 
-all instructions are uppercase , every instruction's operand should be separated by only one space
-out.txt will contain the registers values and all memory locations values

-The immediate value in BNE represents the offset starting from the index of BNE ..
So -8 represents going back 8 instructions

-Please don't use labels 
-Jumps and branches use only immediate values
-Please separate every instruction with ADD R0 R0 R0
-you can't change the value of R0 

-If you violate any of the previously mentioned instructions the out file will be empty This means that there is an exception


